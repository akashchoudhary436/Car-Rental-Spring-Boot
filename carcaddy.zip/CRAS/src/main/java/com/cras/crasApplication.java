package com.cras;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.*"})
public class crasApplication {

	public static void main(String[] args) {
		SpringApplication.run(crasApplication.class, args);
	}

}