package com.cras.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.cras.model.Employee;

import org.springframework.core.ParameterizedTypeReference;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.ui.Model;
import org.springframework.http.HttpHeaders;
import java.util.*;
import java.text.*;

@Controller
public class employeeController {

//	@InitBinder
//	public void initBinder(WebDataBinder binder) {
//	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//	    dateFormat.setLenient(false);
//	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
//	}
	
//	@InitBinder
//	public void initBinder(WebDataBinder binder) {
//
//	}

//	@RequestMapping(value = "/")
	
	@GetMapping("/")
	public String registrationPage(Model model) {

		model.addAttribute("employee", new Employee());// default null. employee binding
		return "empreg";// application.properties config

	}

	@Bean // BEAN COMPONENT OBJ AUTOMATICALLY CREATES ( FIN CLIENT OR restTemplate )
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

//modelattribute employee obj from html to @ModelAttribute("employee") should same then its binded

//	@RequestMapping(value = "/register", method = RequestMethod.POST)
	
	@PostMapping("/register")
	public String submitEmployeeFormPage(@ModelAttribute("employee") Employee employee, Model model)
			throws JsonMappingException, JsonProcessingException {

		String url = "http://localhost:8080/addEmployee";

		// header is used to set data in json

		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");

		// send request to one application to other application
		HttpEntity<Employee> request = new HttpEntity<>(employee, headers);// employee obj

		// Send the POST request
//	        try {
		ResponseEntity<Employee> response = restTemplate().exchange(url, HttpMethod.POST, request, Employee.class);

		// REQUST TO GET THE RESPONCE
		Employee empobj = null;
		empobj = response.getBody();// ACESS THE RESPONCE

//	        }
//	        catch(HttpClientErrorException e) {
//	        	      	
//	        	ObjectMapper objectMapper = new ObjectMapper();
//	            JsonNode rootNode = objectMapper.readTree(e.getResponseBodyAsString());
//	            String errorMessage = rootNode.path("message").asText();
//	        	model.addAttribute("errorMessage", errorMessage);
//	        		return "statuspage";
//	       }

		if (empobj != null)
			return "statuspage";
		else {
			model.addAttribute("errorMessage", "Employee not added to the database");
			return "statuspage";
		}

	}

//	@RequestMapping(value = "/viewAllEmployees", method = RequestMethod.GET)
	
	@GetMapping("/viewAllEmployees")
	public String viewAllEmployees(Model model) {
		List<Employee> emp = new ArrayList<Employee>();
		String url = "http://localhost:8080/viewEmployees";
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");

		HttpEntity<Employee> request = new HttpEntity<>(headers);

//	    try {
		ResponseEntity<List<Employee>> response = restTemplate().exchange(url, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Employee>>() {
				});
		emp = response.getBody();

//	    } catch (HttpClientErrorException | HttpServerErrorException e) {
//	        model.addAttribute("errorMessage", "Unable to fetch employees. Please try again later.");
//	        return "statuspage";
//	    }
		model.addAttribute("employees", emp);
		if (emp != null && emp.size() != 0) {
			System.out.println("inside if of showall");
			return "employeelist";
		} else {
			model.addAttribute("errorMessage", "No record found!!!");
			return "statuspage";
		}
	}

//	@RequestMapping(value = "/view")
	
	@GetMapping("/view")
	public String viewByEmployeePage(@ModelAttribute("name") String name, Model model) {

		model.addAttribute("employee", new Employee());
		return "findbyname";

	}

//	@RequestMapping(value = "/findEmployeeByName", method = RequestMethod.GET)
	
	@GetMapping("/findEmployeeByName")
	public String findEmployeeByName(@RequestParam("name") String name, Model model) {
		List<Employee> emp = new ArrayList<>();
		String url = "http://localhost:8080/viewEmployeeByName/" + name;
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");

//	    try {
		ResponseEntity<List<Employee>> response = restTemplate().exchange(url, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Employee>>() {
				});
		emp = response.getBody();
//	    } catch (HttpClientErrorException | HttpServerErrorException e) {
//	        model.addAttribute("errorMessage", "Unable to fetch employees. Please try again later.");
//	        return "statuspage";
//	    }

		if (emp != null && emp.size() != 0) {
			model.addAttribute("employees", emp);
			return "employeelist";
		} else {
			model.addAttribute("errorMessage", "No employees found with the given name.");
			return "statuspage";
		}
	}

}
