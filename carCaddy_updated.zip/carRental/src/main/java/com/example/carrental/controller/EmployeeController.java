package com.example.carrental.controller;

import com.example.carrental.model.Employee;
import com.example.carrental.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;

@Controller
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    @PostMapping("/register")
    public String registerEmployee(Employee employee, Model model) {
        if ("Temporary".equals(employee.getAccountType()) && employee.getExpiryDate() == null) {
            model.addAttribute("error", "Expiry date is required for Temporary accounts.");
            return "register";
        }

        employeeService.registerEmployee(employee);
        model.addAttribute("message", "Registration successful! Your default password has been generated.");
        return "login";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String loginEmployee(String emailId, String password, Model model) {
        Employee employee = employeeService.loginEmployee(emailId, password);
        if (employee != null) {
            model.addAttribute("message", "Welcome, " + employee.getFullName() + "!");
            return "welcome";
        } else {
            model.addAttribute("error", "Invalid email or password. Please try again.");
            return "login";
        }
    }
    @GetMapping("/logout")
    public String logout() {
        // Implement logout functionality here
        return "redirect:/login";  // Redirect to login page after logout
    }
}
