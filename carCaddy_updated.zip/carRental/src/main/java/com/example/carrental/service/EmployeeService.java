package com.example.carrental.service;

import com.example.carrental.model.Employee;
import com.example.carrental.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public void registerEmployee(Employee employee) {
        String defaultPassword = generateDefaultPassword(employee);
        employee.setPassword(defaultPassword);
        employeeRepository.save(employee);
    }

    public Employee loginEmployee(String emailId, String password) {
        return employeeRepository.findByEmailId(emailId)
                .filter(e -> e.getPassword().equals(password))
                .orElse(null);
    }

    private String generateDefaultPassword(Employee employee) {
        String firstLetter = employee.getAccountType().substring(0, 1).toUpperCase();
        String dobFormatted = employee.getDob().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int nameLength = employee.getFullName().length();
        return firstLetter + dobFormatted + nameLength;
    }
}
